/**
This is a blank template that should handle all the necessary I/O port functions and libraries. The functions are explained in chapter 2. 
 * Written by Miguel Garcia-Ruiz
 * Ver. 1
 * July, 2020
*/
#include <xc.h>
#include <stdio.h>
#include "mcc_generated_files/mcc.h"

void main(void)
{
    // initializing the microcontroller board:
    SYSTEM_Initialize();

    while (1) //infinite loop
    {
        
    }
}
/**
 End of File 
*/
