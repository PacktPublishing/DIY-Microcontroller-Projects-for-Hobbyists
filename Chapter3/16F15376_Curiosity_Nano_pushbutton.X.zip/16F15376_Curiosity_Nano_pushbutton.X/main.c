/**
* This program reads a push button value and toggles a LED value if the push button is pressed.
* The push button is debounced by waiting a number of milliseconds.
* Written by Miguel Garcia-Ruiz
* Ver. 1.0
* October 19, 2020
*/
#include <xc.h>
#include <stdio.h>
#include "mcc_generated_files/mcc.h"

int reading_pushbutton=0;
//unsigned int millis;
void main(void)
{
    // initializing the microcontroller board:
    SYSTEM_Initialize();
    IO_RD2_SetDigitalOutput(); //it sets up port RD2 as output.
    IO_RA0_SetDigitalInput(); //it sets up port RA0 as input.
    IO_RA0_SetPullup(); //activates pull-up internal resistor
    IO_RD2_SetLow(); //initializes output port with LOW logic level
    while (1) //infinite loop
    {
        reading_pushbutton=IO_RA0_GetValue(); //reads RA0 port
        __delay_ms(100); //wait 100 milliseconds to see if push button is still on.
                         // change its value depending on quality of push button.
        reading_pushbutton=IO_RA0_GetValue();
        //ok, the push button is still pressed after those 100 milliseconds.
        if (reading_pushbutton==LOW){
        IO_RD2_Toggle(); // inverts the current output port value
        }
    }
}
/**
 End of File 
*/
