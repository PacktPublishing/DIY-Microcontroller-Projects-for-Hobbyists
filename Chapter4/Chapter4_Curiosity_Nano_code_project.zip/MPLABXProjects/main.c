/*
 This program reads a photoresistor connected to an analog port and analyzes if 
 * the environment has either good light, poor light or it is dark and turns on
 * a green LED, yellow LED and a red LED, respectively.
 * Written by Miguel Garcia-Ruiz
 * Nov. 6, 2020
 * Ver. 1
 */
#include <xc.h>
#include <stdio.h>
#include "mcc_generated_files/mcc.h"

static uint16_t reading_photoresistor=0; 
/*reading_photoresistor is a variable that stores the analog to digital conversion
 * (ADC) value done by the function ADC_GetConversion().
static is a type of variable declaration where the value stored in the variable 
works in all the program. The default value of static variables is 0.
uint16_t allows to declare a variable as unsigned 16-bit integer, meaning that
it will store an integer value up to 65535.
*/
void main(void)
{
    
    SYSTEM_Initialize(); // It initializes the device
    ADC_Initialize();  //It initializes the analog to digital (ADC)(conversion
    while (1) // infinite loop
    {
       IO_RD1_SetLow(); //It sets output port with LOW logic level
       IO_RD2_SetLow(); //It sets output port with LOW logic level
       IO_RD3_SetLow(); //It sets output port with LOW logic level
      
       reading_photoresistor=ADC_GetConversion(channel_ANA0); //reads RA0 port
       //the thresholds of the ADC values are analyzed:
       if (reading_photoresistor>=0 && reading_photoresistor <=128)  
       {
         IO_RD1_SetHigh(); //darkness
       } else if (reading_photoresistor>= 129 && reading_photoresistor<=512)
       {
         IO_RD2_SetHigh(); //dim light
       } else 
       {
         IO_RD3_SetHigh();   // normal (OK) light
       }
       __delay_ms(200); //it lets the photoresistor to read amount of light
    }
    
}
/**
 End of File
*/