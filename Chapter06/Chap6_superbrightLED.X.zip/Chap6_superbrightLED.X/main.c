/* Program that demonstrates how to show an S.O.S. Morse code message using a super bright LED connected to a Blue Pill's output port
 * Written by Miguel Garcia-Ruiz
 * December 10, 2020
 * Ver. 1.0
 */

#include "mcc_generated_files/mcc.h"

const int dot_duration=150; //dot duration in milliseconds
const int dash_duration=dot_duration*3; //dash duration in milliseconds. A dash is three times the dot duration.
const int shortspace_duration=150; // space between letters
const int space_duration=dot_duration*7;//words are separated by a space equivalent to seven dots
         
void shortspace() {
          __delay_ms(shortspace_duration);
} // a short space between letters

void space() {
         __delay_ms(space_duration);
} //a space between words

void dot() { //making a dot with a signal unit, which is short
          IO_RD3_SetHigh(); 
          __delay_ms(dot_duration); 
          IO_RD3_SetLow(); 
          __delay_ms(dot_duration); 
}
           
void dash() { //making a dash with three signal units
          IO_RD3_SetHigh();  
          __delay_ms(dash_duration); 
          IO_RD3_SetLow();
          __delay_ms(dash_duration); 
}

void S() { // making letter S
          dot();
          dot();
          dot();
          shortspace();
}
         
void O() { // making letter O
          dash();
          dash();
          dash();
          shortspace();
}

void main(void)
{
    // initialize the device
    SYSTEM_Initialize();
    IO_RD3_SetLow(); //initializes RD3 port as with low signal.
    while (1) //infinite loop
    {
      S(); O(); S(); //SOS message ("Save Our Souls") 
      space();  // a space in between each SOS word made with seven signal units       
    }
}
/**
 End of File
*/