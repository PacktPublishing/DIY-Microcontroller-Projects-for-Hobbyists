/*
 Program for reading the temperature in Celsius degrees using an LM35 sensor.
 * It turns a green LED on if the temperature is within the thermal comfort zone (23-26 degrees Celsius)
 * according to https://www.ccohs.ca/oshanswers/phys_agents/thermal_comfort.html
 * Written by Miguel Garcia-Ruiz
 * Ver. 1.0
 * November 21, 2020
 */

#include "mcc_generated_files/mcc.h"

static uint16_t LM35read=0; // uint16_t defined an unsigned short 16-bit integer variable
float temp=0.0; //variable for storing the converted value to degrees Celsius

void main(void)
{
    
    SYSTEM_Initialize(); // initialize the device
    ADC_Initialize(); // initialize the analog to digital conversion (ADC))
    while (1)  //endless loop
    {
       IO_RD2_SetLow();
       IO_RD3_SetLow();
       LM35read=ADC_GetConversion(channel_ANA0); // do ADC conversion
       temp=(5.0/1023)*LM35read;
       if (temp>=23.0 && temp<=26.0) //thermal comfort zone
       {
         IO_RD3_SetHigh(); //it turns on green LED
       } else {
         IO_RD2_SetHigh(); //it turns on yellow LED; temp is outside comfort zone
       }    
       __delay_ms(500); //we wait a bit for reading new values from LM35
    }
}
/**
 End of File
*/